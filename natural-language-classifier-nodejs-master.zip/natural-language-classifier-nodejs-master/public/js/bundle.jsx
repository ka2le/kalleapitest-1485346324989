import React from 'react';
import ReactDOM from 'react-dom';
import Demo from '../../views/demo.jsx'

ReactDOM.render(<Demo/>, document.getElementById('root'));
